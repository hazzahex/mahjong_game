# riichi-mahjong-tiles
This repository contains vector graphics and PNG exports of riichi mahjong tiles. The tiles are available in the regular and black variants. Below are example screenshots of the tiles.

<div style="text-align:center">
<img src ="https://raw.githubusercontent.com/FluffyStuff/riichi-mahjong-tiles/master/ExampleRegular.png" />
<img src ="https://raw.githubusercontent.com/FluffyStuff/riichi-mahjong-tiles/master/ExampleBlack.png" />
</div>

## License
The images are licensed under the [Creative Commons Attribution 4.0 International License](http://creativecommons.org/licenses/by/4.0/).